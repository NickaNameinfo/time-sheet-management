import React from 'react'

function TeamLeadProfile() {
  return (
    <div>Profile</div>
  )
}

export default TeamLeadProfile