import React from 'react'

function HrProfile() {
  return (
    <div>Profile</div>
  )
}

export default HrProfile