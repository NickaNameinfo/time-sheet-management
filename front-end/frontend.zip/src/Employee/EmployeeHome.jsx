import axios from "axios";
import React, { useCallback, useEffect, useMemo, useState } from "react";
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import { Button } from "@mui/material";
function EmployeeHome() {
  const containerStyle = { width: "100%", height: "100%" };
  const gridStyle = { height: "100%", width: "100%" };
  const [rowData, setRowData] = useState([]);
  const [refresh, setRefresh] = React.useState(false);
  const [isUpdate, setIsUpdate] = React.useState(true);
  axios.defaults.withCredentials = true;

  const columnDefs = useMemo(
    () => [
      {
        field: "projectName",
        minWidth: 150,
      },
      { field: "tlName", editable: false },
      { field: "taskNo" },
      { field: "areaofWork" },
      { field: "workDate" },
      { field: "workHour" },
      { field: "totalHours" },
      {
        headerName: "Action",
        field: "id",
        filter: false,
        editable: false,
        cellRenderer: (params) => (
          <div className="mb-2">
            <Button
              variant="contained"
              onClick={() => updateProjectDetails(params)}
              disabled={isUpdate}
            >
              Update
            </Button>
          </div>
        ),
      },
    ],
    [isUpdate]
  );

  const autoGroupColumnDef = useMemo(
    () => ({
      headerName: "Group",
      minWidth: 170,
      field: "athlete",
      valueGetter: (params) => {
        if (params.node.group) {
          return params.node.key;
        } else {
          return params.data[params.colDef.field];
        }
      },
      headerCheckboxSelection: false,
      cellRenderer: "agGroupCellRenderer",
      cellRendererParams: {
        checkbox: false,
      },
    }),
    []
  );

  const defaultColDef = useMemo(
    () => ({
      editable: true,
      enableRowGroup: true,
      enablePivot: true,
      enableValue: true,
      sortable: true,
      resizable: true,
      filter: true,
      floatingFilter: true,
      flex: 1,
      minWidth: 100,
    }),
    []
  );
  const onGridReady = useCallback(
    (params) => {
      axios
        .get("http://localhost:8081/getWrokDetails")
        .then(async (res) => {
          let userDetails = await axios.get("http://localhost:8081/dashboard");
          console.log(res, "resres324", userDetails);
          if (res.data.Status === "Success") {
            let filterData = res.data.Result.filter(
              (items) => items.employeeName === userDetails.data.employeeName
            );
            setRowData(filterData);
          } else {
            alert("Error");
          }
        })
        .catch((err) => console.log(err));
    },
    [refresh]
  );

  const updateProjectDetails = (params) => {
    axios
      .put(
        `http://localhost:8081/project/updateWorkDetails/` + params.data.id,
        params.data
      )
      .then(async (res) => {
        setRefresh(true);
        setIsUpdate(true);
        alert("Update Successfully");
      });
    console.log(params.data, "datadatadatadata");
  };

  const onSelectionChanged = (event) => {
    const selectedItem = event.api.getSelectedRows();
    console.log(selectedItem, "selectedItemselectedItem");
  };

  const onChangeValue = (value) => {
    console.log(value, "valuevalue", isUpdate);
    if (value.value) {
      setIsUpdate(false);
    }
  };

  return (
    <>
      <div className="text-center pb-1 my-3">
        <h4>Work Details</h4>
      </div>
      <div style={containerStyle}>
        <div style={gridStyle} className="ag-theme-alpine">
          <AgGridReact
            rowData={rowData}
            columnDefs={columnDefs}
            autoGroupColumnDef={autoGroupColumnDef}
            defaultColDef={defaultColDef}
            suppressRowClickSelection={true}
            groupSelectsChildren={true}
            rowSelection={"single"}
            rowGroupPanelShow={"always"}
            pivotPanelShow={"always"}
            pagination={true}
            onCellEditingStarted={(value) => onChangeValue(value)}
            onGridReady={onGridReady}
            onSelectionChanged={(event) => onSelectionChanged(event)}
          />
        </div>
      </div>
    </>
  );
}

export default EmployeeHome;
